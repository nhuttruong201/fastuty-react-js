const initState = {
    users: [
        { id: 1, name: "1111" },
        { id: 2, name: "2222" },
    ],
};

const rootReducer = (state = initState, action) => {
    return state;
};

export default rootReducer;
